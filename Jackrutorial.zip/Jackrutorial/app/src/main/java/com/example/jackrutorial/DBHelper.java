package com.example.jackrutorial;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.sql.Date;

public class DBHelper extends SQLiteOpenHelper {
    //private String Event;
   // private String Date;
    public static final String Date_Selected = "date";
    public static final String Event_Selected = "event";

    public DBHelper(Context context) {
        super(context, "EventCalendar.db", null, 1);
    }

    private static String EventCalendar;
    private static final String CREATE_SERIES_TABLE = ("create Table"+ EventCalendar + "( " + Date_Selected+" TEXT NOT NULL, " +Event_Selected+" TEXT NOT NULL)");
    @Override
    public void onCreate(SQLiteDatabase DBHelper) {
        //public static final String CREATE_TABLE= "create table "+ TABLE_NAME + " ( "+ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+MESSAGE+" TEXT)";
        DBHelper.execSQL(CREATE_SERIES_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop Table if exists EventCalendar");
    }

    public Boolean insertuserdata(String selectedDate, String textViewTXT)  {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("date", selectedDate);
        contentValues.put("event", textViewTXT);
        long result = DB.insert("EventCalendar", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }//End insertuserdata
    public Cursor getdata (){
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from EventCalendar", null);
        return cursor;

    }
}//End dbHelper

