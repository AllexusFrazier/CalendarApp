package com.example.jackrutorial;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;

import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    CalendarView calendarView;
    Button load_button, add_button, alarm_button;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        load_button = findViewById(R.id.load_button);
        add_button = findViewById(R.id.add_button);
        alarm_button = findViewById(R.id.alarm_button);
        textView = findViewById(R.id.textView);
        calendarView = findViewById(R.id.calendarView);
        dbHelper = new DBHelper(this);

        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long calendarViewTXT = calendarView.getDate();
                String textViewTXT = textView.getText().toString();

                Boolean checkinsertdata = dbHelper.insertuserdata(calendarViewTXT, textViewTXT);
                if (checkinsertdata == true) {
                    Toast.makeText(MainActivity.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                } else
                    Toast.makeText(MainActivity.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
            }
        });//End add_button

        load_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = dbHelper.getdata();
                if (res.getCount() == 0) {
                    Toast.makeText(MainActivity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                    buffer.append("Date:" + res.getString(0) + "\n");
                    buffer.append("Event Entry:" + res.getString(1) + "\n");
                }//End while
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setTitle("User Entries");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });//End load_button
    }//End onCreate
}//End MainActivity