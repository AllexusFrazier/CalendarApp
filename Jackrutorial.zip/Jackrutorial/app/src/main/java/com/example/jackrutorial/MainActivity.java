package com.example.jackrutorial;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;

import android.os.Bundle;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    CalendarView calendarView;
    Button load_button, add_button;
    DBHelper DB;
    String selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        load_button = findViewById(R.id.load_button);
        add_button = findViewById(R.id.add_button);
        textView = findViewById(R.id.textView);
        calendarView = findViewById(R.id.calendarView);
        DB = new DBHelper(this);


        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                //selectedDate = Integer.toString(year) + Integer.toString(month) + Integer.toString(dayOfMonth);
                //selectedDate= year + month + dayOfMonth;
                //ReadDatabase(view);
                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
               selectedDate = sdf.format(new Date(calendarView.getDate()));
            }
        });
               add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String calendarViewTXT = selectedDate.toString();//changed calendarviewtxt to selected date
                String textViewTXT = textView.getText().toString();

                Boolean checkinsertdata = DB.insertuserdata(calendarViewTXT, textViewTXT);
                if (checkinsertdata == true) {
                    Toast.makeText(MainActivity.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                } else
                    Toast.makeText(MainActivity.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
            }
        });//End add_button

        load_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = DB.getdata();
                if (res.getCount() == 0) {
                    Toast.makeText(MainActivity.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                    buffer.append("DateSelected:" + res.getString(0) + "\n");
                    buffer.append("Event:" + res.getString(1) + "\n");
                }//End while
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setTitle("User Entries");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });//End load_button
    }//End onCreate
}//End MainActivity