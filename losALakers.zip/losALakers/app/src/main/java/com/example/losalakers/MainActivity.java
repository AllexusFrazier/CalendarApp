package com.example.losalakers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button);
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);

        button.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
    }

    public void onClick(View v) {
        openMainActivity2();
        openMainActivity3();
        openMainActivity4();
    }


    public void openMainActivity2() {
        Intent head_coach = new Intent(this, MainActivity2.class);
        startActivity(head_coach);
    }

    public void openMainActivity3() {
        Intent players_1 = new Intent(this, MainActivity3.class);
        startActivity(players_1);
    }

    public void openMainActivity4() {
        Intent kobe_bryant = new Intent(this, MainActivity4.class);
        startActivity(kobe_bryant);
    }


}